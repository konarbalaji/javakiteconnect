/**All the models that Kite Connect uses are here.*/
package com.zerodhatech.models;