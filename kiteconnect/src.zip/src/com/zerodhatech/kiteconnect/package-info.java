/** Offers all functionality that Kite Connect can provide for building a platform.*/
package com.zerodhatech.kiteconnect;