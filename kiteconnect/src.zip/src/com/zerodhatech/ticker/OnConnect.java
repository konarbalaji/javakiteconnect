package com.zerodhatech.ticker;

/**
 * Callback to listen to com.zerodhatech.ticker websocket connected event.
 */
public interface OnConnect {
    void onConnected();
}
